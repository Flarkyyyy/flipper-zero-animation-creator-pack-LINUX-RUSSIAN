#!/bin/bash
# Использование: ./gif2flipper.sh input.gif my_anim
IN="$1"
NAME="${2:-my_anim}"
FPS=8

mkdir -p "$NAME"

ffmpeg -y -i "$IN" \
  -vf "fps=$FPS,scale=128:64:force_original_aspect_ratio=decrease,pad=128:64:(ow-iw)/2:(oh-ih)/2:black,format=gray" \
  -start_number 0 -pix_fmt monob "$NAME/frame_%d.png"

N=$(ls "$NAME"/frame_*.png | wc -l)
ORDER=$(seq -s ' ' 0 $((N-1)))

cat > "$NAME/meta.txt" <<EOF
Filetype: Flipper Animation
Version: 1

Width: 128
Height: 64
Passive frames: $N
Active frames: 0
Frames order: $ORDER
Active cycles: 0
Frame rate: $FPS
Duration: 3600
Active cooldown: 0

Bubble slots: 0
EOF

echo "Готово: $N кадров в папке $NAME"
