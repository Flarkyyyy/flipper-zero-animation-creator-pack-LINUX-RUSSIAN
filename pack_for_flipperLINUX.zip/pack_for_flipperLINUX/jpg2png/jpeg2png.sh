#!/bin/bash
# Использование: ./convert_frames.sh [папка_с_кадрами]
# Без аргумента работает в текущей папке.

DIR="${1:-.}"
OUT="$DIR/out"
mkdir -p "$OUT"

N=0
for f in "$DIR"/frame_*.jpg "$DIR"/frame_*.jpeg "$DIR"/frame_*.png; do
  [ -e "$f" ] || continue
  base=$(basename "$f")
  num="${base#frame_}"
  num="${num%.*}"

  ffmpeg -loglevel error -y -i "$f" \
    -vf "scale=128:64,format=gray,lut=y='if(gt(val,128),255,0)'" \
    -pix_fmt monob "$OUT/frame_$num.png"

  N=$((N+1))
done

if [ "$N" -eq 0 ]; then
  echo "Кадры frame_*.jpg не найдены в $DIR"
  exit 1
fi

ORDER=$(seq -s ' ' 0 $((N-1)))

cat > "$OUT/meta.txt" <<EOF
Filetype: Flipper Animation
Version: 1

Width: 128
Height: 64
Passive frames: $N
Active frames: 0
Frames order: $ORDER
Active cycles: 0
Frame rate: 1
Duration: 3600
Active cooldown: 0

Bubble slots: 0
EOF

echo "Готово: $N кадров и meta.txt в $OUT"
